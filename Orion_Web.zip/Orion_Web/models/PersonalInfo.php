<?php
    class PersonalInfo {
        public $id;
        public $fullname;
        public $email;
        public $phone;
        public $address;
        public $date_of_birth;
    }
?>