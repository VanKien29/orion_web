<?php

spl_autoload_register(function ($class) {    
    $fileName = "class.php";

    $fileModel = PATH_MODEL . $fileName;
    $fileController = PATH_CONTROLLER . $fileName;

    if (is_readable($fileModel)) {
        require_once $fileModel;
    } 
    else if (is_readable($fileController)) {
        require_once $fileController;
    }
});

require_once './configs/env.php';
require_once './configs/helper.php';

$act = $_GET['act'] ?? '/';

match ($act) {
    '/'         => (new HomeController)->index(),
    'so-thich' => (new HomeController)->soThich(),
    'thong-tin' => (new HomeController)->thongTin(),
    'hoi-dap'  => (new HomeController)->hoiDap(),
    'tao-cau-hoi'  => (new HomeController)->taoCauHoi(),
    'bang-xep-hang' => (new HomeController)->bangXepHang(),
    'login' => (new HomeController)->login(),
    'logout' => (new HomeController)->logout(),
    'register' => (new HomeController)->register(),
};