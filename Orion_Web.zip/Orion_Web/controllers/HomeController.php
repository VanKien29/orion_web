<?php

class HomeController
{
    public function index()
    {
        $title = 'Home';
        $view = 'home'; 
        include PATH_VIEW_MAIN;
    }

    public function hoiDap()
    {
        $title = 'Hỏi đáp';
        $view = 'hoi_dap';
        if (isset($_POST['question'])) {
            $modelAi = $_POST['model-ai'] ?? array_key_first(MODEL_OPTIONS);
            $answer = openrouter_api($modelAi, $_POST['question']);
        }
        include PATH_VIEW_MAIN;
    }

    public function taoCauHoi()
    {
        $title = 'Tạo câu hỏi bởi AI';
        $view = 'tao_cau_hoi';
        $questions = [];
        $topics = [
            'Thuật toán' => 'Tạo 5 câu hỏi liên quan đến thuật toán lập trình (ví dụ: sắp xếp, tìm kiếm, độ phức tạp).',
            'Ngôn ngữ lập trình' => 'Tạo 5 câu hỏi liên quan đến các ngôn ngữ lập trình (ví dụ: Python, Java, C++).',
            'Cấu trúc dữ liệu' => 'Tạo 5 câu hỏi liên quan đến cấu trúc dữ liệu (ví dụ: mảng, danh sách liên kết, cây).'
        ];

        if (isset($_POST['topic'])) {
            $selectedTopic = $_POST['topic'];
            $prompt = $topics[$selectedTopic] ?? $topics['Thuật toán'];
            $response = openrouter_api(MODEL_DEEPSEEK_R1, $prompt);
            $questions = explode("\n", trim($response));
            $questions = array_filter($questions);
        }

        include PATH_VIEW_MAIN;
    }

    public function bangXepHang()
{
    $title = 'Bảng xếp hạng';
    $view = 'banh_xep_hang';
    require_once PATH_MODEL . 'BaseModel.php';
    $model = new BaseModel();
    $stmt = $model->getPdo()->query("SELECT username, score, '' AS evaluation FROM users ORDER BY score DESC LIMIT 10");
    $rankings = $stmt->fetchAll();
    include PATH_VIEW_MAIN;
}

    public function login()
    {
        ob_start();
        $title = 'Đăng nhập';
        $view = 'login';
        $error = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = $_POST['username'];
            $password = $_POST['password'];
            $model = new BaseModel();
            $stmt = $model->getPdo()->prepare("SELECT * FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch();
            if ($user && $password === $user['password']) {
                session_start();
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                header("Location: " . BASE_URL . "?act=/");
                ob_end_flush();
                exit;
            } else {
                $error = "Tên đăng nhập hoặc mật khẩu không đúng.";
            }
        }
        include PATH_VIEW_MAIN;
        ob_end_flush();
    }

    public function logout()
    {
        session_start();
        session_destroy();
        header("Location: " . BASE_URL . "?act=login");
        exit;
    }
    
    public function register()
    {
        ob_start();
        $title = 'Đăng ký';
        $view = 'register';
        $error = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = $_POST['username'];
            $password = $_POST['password']; 
            $model = new BaseModel();
            $stmt = $model->getPdo()->prepare("SELECT * FROM users WHERE username = ?");
            $stmt->execute([$username]);
            if ($stmt->fetch()) {
                $error = "Tên đăng nhập đã tồn tại!";
            } else {
                $stmt = $model->getPdo()->prepare("INSERT INTO users (username, password, score) VALUES (?, ?, 0)");
                $stmt->execute([$username, $password]);
                header("Location: " . BASE_URL . "?act=login");
                ob_end_flush();
                exit;
            }
        }
        include PATH_VIEW_MAIN;
        ob_end_flush();
    }
}