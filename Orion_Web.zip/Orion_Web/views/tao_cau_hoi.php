<h2>Tạo câu hỏi bởi AI</h2>
<form method="POST" action="" class="form-topic">
    <label for="topic">Chọn chủ đề:</label>
    <select name="topic" id="topic" required>
        <option value="">-- Chọn chủ đề --</option>
        <option value="Thuật toán">Thuật toán</option>
        <option value="Ngôn ngữ lập trình">Ngôn ngữ lập trình</option>
        <option value="Cấu trúc dữ liệu">Cấu trúc dữ liệu</option>
    </select>
    <button type="submit" name="tao_cau_hoi">Tạo câu hỏi</button>
</form>

<?php
require_once dirname(__DIR__) . '/configs/env.php';

if (isset($_POST['tao_cau_hoi'])) {
    $topic = $_POST['topic'];
    $apiUrl = API_OPENROUTER_URL;
    $apiKey = API_OPENROUTER_KEY;

    // Tạo prompt cho AI
    $prompt = "Hãy tạo 5 câu hỏi trắc nghiệm về chủ đề: $topic. 
    Mỗi câu hỏi trả về dạng JSON: 
    [{\"question\": \"...\", \"answers\": [\"A\", \"B\", \"C\", \"D\"], \"correct\": 0}, ...]";

    // Chuẩn bị dữ liệu gửi đi
    $data = [
        "model" => MODEL_DEEPSEEK_R1,
        "messages" => [
            ["role" => "user", "content" => $prompt]
        ]
    ];

    $ch = curl_init($apiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer $apiKey",
        "Content-Type: application/json"
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    $response = curl_exec($ch);
    curl_close($ch);

    $result = json_decode($response, true);

    $questionsFromAI = [];
    if (isset($result['choices'][0]['message']['content'])) {
        $json = $result['choices'][0]['message']['content'];
        $json = trim($json);
        $json = preg_replace('/^```(json)?/i', '', $json); 
        $json = preg_replace('/```$/', '', $json);         
        $json = trim($json);

        $questionsFromAI = json_decode($json, true);

        
        if (!is_array($questionsFromAI)) {
            if (preg_match('/(\[.*\])$/s', $json, $matches)) {
                $questionsFromAI = json_decode($matches[1], true);
            }
        }
    }

    if (is_array($questionsFromAI) && isset($questionsFromAI[0]['question'])) {
        $_SESSION['questions_ai'] = $questionsFromAI;
    } else {
        $_SESSION['questions_ai'] = [];
        echo "<div class='alert alert-danger'>Không lấy được câu hỏi từ AI!</div>";
    }
}


$questions = $_SESSION['questions_ai'] ?? [];
$userAnswers = $_POST['answer'] ?? [];
$showResult = isset($_POST['submit_answers']);
$score = 0;

if ($showResult) {
    foreach ($questions as $qIndex => $q) {
        if (isset($userAnswers[$qIndex]) && $userAnswers[$qIndex] == $q['correct']) {
            $score++;
        }
    }
    if (isset($_SESSION['user_id'])) {
        require_once dirname(__DIR__) . '/models/BaseModel.php';
        $model = new BaseModel();
        $stmt = $model->getPdo()->prepare("UPDATE users SET score = score + ? WHERE id = ?");
        $stmt->execute([$score, $_SESSION['user_id']]);
    }
    echo "<div class='alert alert-success mt-3'>Bạn đúng $score/" . count($questions) . " câu!</div>";
    unset($_SESSION['questions_ai']);
}
?>

<?php if (!empty($questions)): ?>
<h3>Các câu hỏi được tạo:</h3>
<form method="POST" action="">
    <?php foreach ($questions as $qIndex => $q): ?>
    <div class="mb-4 question-box">
        <div class="fw-bold"><?= ($qIndex+1) . '. ' . htmlspecialchars($q['question']) ?></div>
        <?php foreach ($q['answers'] as $aIndex => $answer): 
            $isChecked = isset($userAnswers[$qIndex]) && $userAnswers[$qIndex] == $aIndex;
            $isCorrect = $q['correct'] == $aIndex;
            $showFeedback = $showResult && ($isChecked || $isCorrect);
        ?>
        <div class="answer-row">
            <label
                class="answer-label <?= $showResult ? ($isCorrect ? 'answer-correct' : ($isChecked ? 'answer-incorrect' : '')) : '' ?>">
                <input type="radio" name="answer[<?= $qIndex ?>]" value="<?= $aIndex ?>"
                    <?= $isChecked ? 'checked' : '' ?> <?= $showResult ? 'disabled' : '' ?> required>
                <?= htmlspecialchars($answer) ?>
                <?php if ($showResult && $isCorrect): ?>
                <span class="badge bg-success ms-2">Đáp án đúng</span>
                <?php elseif ($showResult && $isChecked && !$isCorrect): ?>
                <span class="badge bg-danger ms-2">Bạn chọn</span>
                <?php endif; ?>
            </label>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endforeach; ?>
    <?php if (!$showResult): ?>
    <button type="submit" name="submit_answers">Nộp bài</button>
    <?php endif; ?>
</form>
<?php endif; ?>

<style>
.form-topic {
    max-width: 420px;
    margin: 32px auto 24px auto;
    padding: 24px 24px 18px 24px;
    background: #fff;
    border-radius: 14px;
    box-shadow: 0 2px 16px rgba(0, 0, 0, 0.07);
}

.form-topic label {
    font-weight: 600;
    color: #0d6efd;
    margin-bottom: 8px;
    display: block;
    font-size: 1.08rem;
}

.form-topic select {
    width: 100%;
    padding: 10px 12px;
    border: 1px solid #d0d7de;
    border-radius: 8px;
    font-size: 1rem;
    margin-bottom: 18px;
    transition: border-color 0.2s;
}

.form-topic select:focus {
    border-color: #0d6efd;
    outline: none;
}

.form-topic button[type="submit"] {
    width: 100%;
    background: linear-gradient(90deg, #0dcaf0 60%, #0d6efd 100%);
    color: #fff;
    border: none;
    border-radius: 8px;
    padding: 12px 0;
    font-size: 1.08rem;
    font-weight: 600;
    cursor: pointer;
    transition: background 0.2s, box-shadow 0.2s;
}

.form-topic button[type="submit"]:hover {
    background: linear-gradient(90deg, #0d6efd 60%, #0dcaf0 100%);
    box-shadow: 0 2px 8px rgba(13, 110, 253, 0.08);
}

.question-box {
    background: #f8fafd;
    border-radius: 12px;
    padding: 18px 18px 10px 18px;
    margin-bottom: 18px;
    box-shadow: 0 2px 12px rgba(13, 110, 253, 0.06);
}

.answer-row {
    margin-bottom: 6px;
}

.answer-label {
    display: flex;
    align-items: center;
    padding: 7px 12px;
    border-radius: 8px;
    transition: background 0.2s;
    font-size: 1.04rem;
}

.answer-label input[type="radio"] {
    margin-right: 8px;
}

.answer-correct {
    background: #e7fbe7;
    font-weight: 600;
}

.answer-incorrect {
    background: #fde7e7;
}

.badge.bg-success {
    background: #198754 !important;
}

.badge.bg-danger {
    background: #dc3545 !important;
}
</style>