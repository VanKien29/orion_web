<style>
.register-box {
    max-width: 400px;
    margin: 48px auto;
    padding: 32px 28px 24px 28px;
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 2px 16px rgba(0, 0, 0, 0.07);
}

.register-box h2 {
    text-align: center;
    color: #0d6efd;
    font-weight: 700;
    margin-bottom: 24px;
}

.register-box label {
    display: block;
    margin-bottom: 6px;
    font-weight: 600;
    color: #0d6efd;
}

.register-box input[type="text"],
.register-box input[type="password"] {
    width: 100%;
    padding: 10px 12px;
    margin-bottom: 18px;
    border: 1px solid #d0d7de;
    border-radius: 8px;
    font-size: 1rem;
    transition: border-color 0.2s;
}

.register-box input:focus {
    border-color: #0d6efd;
    outline: none;
}

.register-box button[type="submit"] {
    width: 100%;
    background: linear-gradient(90deg, #0dcaf0 60%, #0d6efd 100%);
    color: #fff;
    border: none;
    border-radius: 8px;
    padding: 12px 0;
    font-size: 1.08rem;
    font-weight: 600;
    cursor: pointer;
    transition: background 0.2s, box-shadow 0.2s;
    margin-top: 8px;
}

.register-box button[type="submit"]:hover {
    background: linear-gradient(90deg, #0d6efd 60%, #0dcaf0 100%);
    box-shadow: 0 2px 8px rgba(13, 110, 253, 0.08);
}

.register-box p {
    text-align: center;
    margin-top: 18px;
}

.register-box a {
    color: #0d6efd;
    text-decoration: none;
    font-weight: 500;
}

.register-box a:hover {
    text-decoration: underline;
    color: #0dcaf0;
}
</style>
<div class="register-box">
    <h2>Đăng ký</h2>
    <?php
    $error = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $username = $_POST['username'];
        $password = $_POST['password'];
        $model = new BaseModel();
        $stmt = $model->getPdo()->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            $error = "Tên đăng nhập đã tồn tại!";
        } else {
            $stmt = $model->getPdo()->prepare("INSERT INTO users (username, password, score) VALUES (?, ?, 0)");
            $stmt->execute([$username, $password]);
            header("Location: " . BASE_URL . "?act=login");
            exit;
        }
    }
    ?>
    <?php if ($error): ?>
    <p style="color: red;"><?php echo $error; ?></p>
    <?php endif; ?>
    <form method="POST" action="">
        <label for="username">Tên đăng nhập:</label>
        <input type="text" name="username" id="username" required>
        <label for="password">Mật khẩu:</label>
        <input type="password" name="password" id="password" required>
        <button type="submit">Đăng ký</button>
    </form>
    <p><a href="<?php echo BASE_URL; ?>?act=login">Đăng nhập</a></p>
</div>