<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?= $title ?? 'Home' ?></title>


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
    body {
        background: #f8fafc;
    }

    .navbar {
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.07);
        background: linear-gradient(90deg, #0dcaf0 60%, #0d6efd 100%) !important;
    }

    .navbar-nav .nav-link {
        font-weight: 600;
        font-size: 1.08rem;
        border-radius: 8px;
        transition:
            background 0.2s,
            color 0.2s,
            box-shadow 0.2s;
        margin: 0 4px;
        padding: 10px 22px;
        position: relative;
        letter-spacing: 0.5px;
    }

    .navbar-nav .nav-link:hover,
    .navbar-nav .nav-link.active {
        background: #fff;
        color: #0d6efd !important;
        box-shadow: 0 2px 8px rgba(13, 110, 253, 0.12);
        font-weight: 700;
        text-decoration: none;
        transform: translateY(-2px) scale(1.04);
    }

    .navbar-nav .nav-link:active {
        background: #e3f2fd;
        color: #0d6efd !important;
    }


    .main-menu {
        background: #fff;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
        border-radius: 0 0 16px 16px;
        margin-bottom: 18px;
    }

    .main-menu .nav-link {
        color: #0d6efd;
        font-weight: 500;
        font-size: 1.08rem;
        padding: 12px 28px;
        border-radius: 8px;
        transition:
            background 0.2s,
            color 0.2s,
            box-shadow 0.2s;
        margin: 0 4px;
        position: relative;
    }

    .main-menu .nav-link:hover,
    .main-menu .nav-link.active {
        background: linear-gradient(90deg, #0dcaf0 60%, #0d6efd 100%);
        color: #fff !important;
        box-shadow: 0 2px 8px rgba(13, 110, 253, 0.08);
        font-weight: 700;
        text-decoration: none;
    }

    .container {
        margin-top: 24px;
        border-radius: 16px;
        box-shadow: 0 2px 16px rgba(0, 0, 0, 0.04);
        padding-bottom: 32px;
    }

    h1 {
        font-size: 2.2rem;
        font-weight: 700;
        color: #0d6efd;
        margin-bottom: 18px;
    }

    .text-muted {
        font-size: 1.1rem;
    }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light shadow-sm"
        style="background: linear-gradient(90deg, #0dcaf0 60%, #0d6efd 100%); border-radius: 0 0 18px 18px;">
        <div class="container">
            <a class="navbar-brand fw-bold text-white text-uppercase" href="<?= BASE_URL ?>">
                <i class="bi bi-stars"></i> Orion Web
            </a>
            <ul class="navbar-nav ms-auto flex-row gap-2">
                <li class="nav-item">
                    <a class="nav-link text-white" href="?act=hoi-dap">Hỏi đáp</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="?act=tao-cau-hoi">Tạo câu hỏi</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="?act=bang-xep-hang">Bảng xếp hạng</a>
                </li>
                <?php if (isset($_SESSION['username'])) : ?>
                <li class="nav-item">
                    <a class="nav-link text-white" href="?act=logout">Đăng xuất (<?= $_SESSION['username']; ?>)</a>
                </li>
                <?php else : ?>
                <li class="nav-item">
                    <a class="nav-link text-white" href="?act=login">Đăng nhập</a>
                </li>
                <?php endif; ?>
                <?php if (!isset($_SESSION['username'])) : ?>
                <li class="nav-item">
                    <a class="nav-link text-white" href="?act=register">Đăng ký</a>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <div class="container bg-light pt-3">
        <div class="row">
            <div class="col-12">
                <h1><?= $title ?? 'Home' ?></h1>
                <?php if (($view ?? '') === 'home'): ?>
                <div class="alert alert-info shadow-sm mb-4">
                    <h4 class="mb-2 text-primary"><i class="bi bi-stars"></i> Chào mừng đến với Orion Web</h4>
                    <ul>
                        <li><b>Hỏi đáp AI:</b> Đặt câu hỏi và nhận câu trả lời tức thì từ các mô hình AI hiện đại.</li>
                        <li><b>Tạo câu hỏi:</b> Đóng góp câu hỏi cho cộng đồng, giúp hệ thống ngày càng thông minh hơn.
                        </li>
                        <li><b>Bảng xếp hạng:</b> Cạnh tranh điểm số, vươn lên top bảng xếp hạng người dùng tích cực
                            nhất.</li>
                        <li><b>Bảo mật & dễ sử dụng:</b> Đăng ký, đăng nhập nhanh chóng, giao diện thân thiện, hỗ trợ đa
                            thiết bị.</li>
                    </ul>
                    <div class="mt-2">
                        <b>Hướng dẫn nhanh:</b>
                        <ol>
                            <li>Chọn <span class="text-primary">Hỏi đáp</span> để bắt đầu trò chuyện với AI.</li>
                            <li>Muốn đóng góp? Hãy vào <span class="text-primary">Tạo câu hỏi</span>.</li>
                            <li>Xem thành tích tại <span class="text-primary">Bảng xếp hạng</span>.</li>
                            <li>Đăng ký tài khoản để lưu lịch sử và tích điểm!</li>
                        </ol>
                    </div>
                </div>
                <?php endif; ?>
                <?php
                    if (isset($view) && $view !== 'home') {
                        require_once PATH_VIEW . $view . '.php';
                    }
                ?>
            </div>
        </div>
    </div>

</body>

</html>