<?php

if (isset($_POST['submitQA'])) {
    $_SESSION['qa_history'][] = [
        'question' => $_POST['question'],
        'answer' => $answer
    ];
}
$history = $_SESSION['qa_history'] ?? [];
?>

<div class="container">
    <div class="card p-4 mt-4" style="white-space: pre-line; max-height: 320px; overflow-y: auto;">
        <h2>Lịch sử hỏi đáp:</h2>
        <?php if (!empty($history)): ?>
        <?php foreach (array_reverse($history) as $item): ?>
        <div class="mb-3">
            <div class="fw-bold text-primary">Câu hỏi:</div>
            <div><?= htmlspecialchars($item['question']) ?></div>
            <div class="fw-bold text-success mt-2">Trả lời:</div>
            <div><?= htmlspecialchars($item['answer']) ?></div>
            <hr>
        </div>
        <?php endforeach; ?>
        <?php else: ?>
        <div class="text-muted">Chưa có câu hỏi nào.</div>
        <?php endif; ?>
    </div>

    <form action="index.php?act=hoi-dap" method="POST">
        <div class="form-group mt-3">
            <label class="form-label">Danh sách Model</label>
            <select class="form-select" name="model-ai">
                <?php foreach (MODEL_OPTIONS as $key => $value): ?>
                <option value="<?= $key ?>"><?= $value ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group mt-3">
            <label class="form-label">Nhập câu hỏi:</label>
            <textarea class="form-control" id="question" name="question" rows="4" required></textarea>
        </div>

        <button type="submit" class="btn btn-success mt-3" name="submitQA">Submit</button>
    </form>
</div>

<style>
.card {
    border-radius: 16px;
    box-shadow: 0 2px 12px rgba(0, 0, 0, 0.06);
    border: none;
    background: #fff;
}

.card h2 {
    color: #0d6efd;
    font-size: 1.4rem;
    font-weight: 700;
    margin-bottom: 12px;
}

.form-label {
    font-weight: 600;
    color: #0d6efd;
    margin-bottom: 6px;
    display: block;
}

.form-group {
    margin-bottom: 18px;
}

.form-control,
.form-select {
    border-radius: 8px;
    border: 1px solid #d0d7de;
    box-shadow: none;
    transition: border-color 0.2s;
}

.form-control:focus,
.form-select:focus {
    border-color: #0d6efd;
    box-shadow: 0 0 0 2px rgba(13, 110, 253, 0.08);
}

.btn-success {
    border-radius: 8px;
    padding: 10px 28px;
    font-weight: 600;
    font-size: 1.08rem;
    transition: background 0.2s, box-shadow 0.2s;
}

.btn-success:hover {
    background: linear-gradient(90deg, #0dcaf0 60%, #0d6efd 100%);
    color: #fff;
    box-shadow: 0 2px 8px rgba(13, 110, 253, 0.08);
}
</style>