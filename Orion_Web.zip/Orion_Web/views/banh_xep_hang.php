<h2 class="text-primary mb-4">Bảng xếp hạng</h2>
<div class="table-responsive">
    <table class="table table-bordered table-hover align-middle shadow-sm ranking-table">
        <thead class="table-primary">
            <tr>
                <th scope="col">#</th>
                <th scope="col">Tên người dùng</th>
                <th scope="col">Điểm số</th>
                <th scope="col">Đánh giá</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($rankings)): ?>
            <?php $rank = 1; foreach ($rankings as $user): ?>
            <tr>
                <td><b><?= $rank++; ?></b></td>
                <td><?= htmlspecialchars($user['username'], ENT_QUOTES, 'UTF-8'); ?></td>
                <td class="text-success fw-bold"><?= htmlspecialchars($user['score'], ENT_QUOTES, 'UTF-8'); ?></td>
                <td><?= htmlspecialchars($user['evaluation'], ENT_QUOTES, 'UTF-8'); ?></td>
            </tr>
            <?php endforeach; ?>
            <?php else: ?>
            <tr>
                <td colspan="4" class="text-center text-muted">Chưa có dữ liệu xếp hạng.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<style>
.ranking-table {
    border-radius: 14px;
    overflow: hidden;
    background: #fff;
    box-shadow: 0 2px 16px rgba(0, 0, 0, 0.06);
}

.ranking-table th,
.ranking-table td {
    vertical-align: middle !important;
    font-size: 1.08rem;
}

.ranking-table thead th {
    background: linear-gradient(90deg, #0dcaf0 60%, #0d6efd 100%);
    color: #fff;
    border: none;
}

.ranking-table tr {
    transition: background 0.2s;
}

.ranking-table tbody tr:hover {
    background: #e3f2fd;
}
</style>
<?php
function getEvaluationFromAI($score) {
    static $cache = [];
    if (isset($cache[$score])) return $cache[$score];

    $apiUrl = API_OPENROUTER_URL;
    $apiKey = API_OPENROUTER_KEY;
    $prompt = "Hãy đánh giá ngắn gọn (dưới 15 từ, không chấm điểm lại) cho người dùng đạt $score điểm trong bảng xếp hạng trắc nghiệm lập trình.";

    $data = [
        "model" => MODEL_DEEPSEEK_R1,
        "messages" => [
            ["role" => "user", "content" => $prompt]
        ]
    ];

    $ch = curl_init($apiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer $apiKey",
        "Content-Type: application/json"
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    $response = curl_exec($ch);
    curl_close($ch);

    $result = json_decode($response, true);
    $evaluation = '';
    if (isset($result['choices'][0]['message']['content'])) {
        $evaluation = trim($result['choices'][0]['message']['content']);
        $evaluation = preg_replace('/^```(.*?)```$/s', '', $evaluation);
    }
    $cache[$score] = $evaluation;
    return $evaluation;
}
?>