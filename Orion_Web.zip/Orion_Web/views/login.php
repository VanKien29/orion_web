<style>
.login-box {
    max-width: 380px;
    margin: 48px auto;
    padding: 32px 28px 24px 28px;
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 2px 16px rgba(0, 0, 0, 0.07);
}

.login-box h2 {
    text-align: center;
    color: #0d6efd;
    font-weight: 700;
    margin-bottom: 24px;
}

.login-box label {
    display: block;
    margin-bottom: 6px;
    font-weight: 600;
    color: #0d6efd;
}

.login-box input[type="text"],
.login-box input[type="password"] {
    width: 100%;
    padding: 10px 12px;
    margin-bottom: 18px;
    border: 1px solid #d0d7de;
    border-radius: 8px;
    font-size: 1rem;
    transition: border-color 0.2s;
}

.login-box input:focus {
    border-color: #0d6efd;
    outline: none;
}

.login-box button[type="submit"] {
    width: 100%;
    background: linear-gradient(90deg, #0dcaf0 60%, #0d6efd 100%);
    color: #fff;
    border: none;
    border-radius: 8px;
    padding: 12px 0;
    font-size: 1.08rem;
    font-weight: 600;
    cursor: pointer;
    transition: background 0.2s, box-shadow 0.2s;
    margin-top: 8px;
}

.login-box button[type="submit"]:hover {
    background: linear-gradient(90deg, #0d6efd 60%, #0dcaf0 100%);
    box-shadow: 0 2px 8px rgba(13, 110, 253, 0.08);
}

.login-box p {
    text-align: center;
    margin-top: 18px;
}

.login-box a {
    color: #0d6efd;
    text-decoration: none;
    font-weight: 500;
}

.login-box a:hover {
    text-decoration: underline;
    color: #0dcaf0;
}
</style>
<div class="login-box">
    <h2>Đăng nhập</h2>
    <?php if ($error): ?>
    <p style="color: red;"><?php echo $error; ?></p>
    <?php endif; ?>
    <form method="POST" action="">
        <label for="username">Tên đăng nhập:</label>
        <input type="text" name="username" id="username" required>
        <label for="password">Mật khẩu:</label>
        <input type="password" name="password" id="password" required>
        <button type="submit" name="login">Đăng nhập</button>
    </form>
    <p><a href="<?php echo BASE_URL; ?>?act=register">Đăng ký</a></p>
</div>